
// Tp3_FT_SciCDlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "Tp3_FT_SciC.h"
//#include "src/Tp3_FT_SciCDlg.h"
#include "afxdialogex.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX){
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CTp3FTSciCDlg dialog



CTp3FTSciCDlg::CTp3FTSciCDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TP3_FT_SCIC_DIALOG, pParent){
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	mydisplay = NULL;
}

void CTp3FTSciCDlg::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, box1);
	DDX_Control(pDX, IDC_EDIT2, box2);
	DDX_Control(pDX, IDC_EDIT3, box3);
}

BEGIN_MESSAGE_MAP(CTp3FTSciCDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CTp3FTSciCDlg::OnbnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CTp3FTSciCDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CTp3FTSciCDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CTp3FTSciCDlg::OnBnClickedApproxim)
	
END_MESSAGE_MAP()


// CTp3FTSciCDlg message handlers

BOOL CTp3FTSciCDlg::OnInitDialog(){
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr){
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty()){
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTp3FTSciCDlg::OnSysCommand(UINT nID, LPARAM lParam){
	if ((nID & 0xFFF0) == IDM_ABOUTBOX){
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTp3FTSciCDlg::OnPaint(){
	if (IsIconic()){
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTp3FTSciCDlg::OnQueryDragIcon(){
	return static_cast<HCURSOR>(m_hIcon);
}



void CTp3FTSciCDlg::kill_child_bn(){ //fonction servant a tuer la fenetre dialogue
	mydisplay->DestroyWindow();
	delete mydisplay;
	mydisplay = NULL;
}

//cubic
void CTp3FTSciCDlg::OnbnClickedButton1() { //fonction servant a afficher la spline cubique
	if(checkInputs()) {
		make_appear();
		mathboi.draw_emptygraph(mydisplay);
		mathboi.draw_cubgraph(mydisplay);
	}
}

//lineair
void CTp3FTSciCDlg::OnBnClickedButton2(){ //fonction servant a afficher la spline lineair
	if(checkInputs()) {
		make_appear();
		mathboi.draw_emptygraph(mydisplay);
		mathboi.draw_lingraph(mydisplay);
	}
}

//hybrid
void CTp3FTSciCDlg::OnBnClickedButton3(){ //fonction servant a afficher la spline lineair et cubique
	if(checkInputs()) {
		make_appear();
		mathboi.draw_emptygraph(mydisplay);
		mathboi.draw_lingraph(mydisplay);
		mathboi.draw_cubgraph(mydisplay);
	}
	
}


void CTp3FTSciCDlg::OnBnClickedApproxim(){//fonction qui aurait servi a faire marcher l<approximation si javait eu le temps
	if(checkInputs()) {
		make_appear();

	}
}

bool CTp3FTSciCDlg::checkInputs() { // fonction verifiant les entrers et settant des valer par default
	CString str,str_right,str_left,path = NULL;
	int i,high_index = -1,low_index = 0,len = NULL;

	// Check pour path
	len = box3.LineLength(box3.LineIndex(1));
	box3.GetLine(1, str.GetBuffer(len), len);
	str.ReleaseBuffer(len);
	str = str.Trim();
	if(len == 0) {
		//path = "//HGN200mg.txt";
		char cwd[256];
		path = _getcwd(cwd, 256);
		path.Append(_T("\\HGN200mg.txt"));
		TRACE(traceAppMsg, 0, path);
	}
	else {
		path = str;
	}


	// Check pour le pas
	len = box1.LineLength(box1.LineIndex(1));
	box1.GetLine(1, str.GetBuffer(len), len);
	str.ReleaseBuffer(len);
	str = str.Trim();
	if(len == 0) {
		mathboi.set_pas(1);
		goto endofcheck_pas;
	}
	
	if(!is_Number(&str,true)) { 
		TRACE(traceAppMsg, 0, _T("FALSE box1 is not a number:  ") + str + _T("/n"));
		return false; 
	}
	mathboi.set_pas(_tstof((LPCTSTR)str));

	endofcheck_pas:

	// Check range point
	len = box3.LineLength(box3.LineIndex(1));
	box3.GetLine(1, str.GetBuffer(len), len);
	str.ReleaseBuffer(len);
	str = str.Trim();
	if(len == 0) { 
		goto endofcheck_range; 
	}
	
	for(i = 0; i <= len; i++) { //cherche un tiret
		if(str.GetAt(i) == '-') {
			break;
		}
	}
	if(len == i || len == i-1) {
		TRACE(traceAppMsg, 0, _T("FALSE no (-) in box3:  ") + str +_T("/n"));
		return false;
	}
	str_left = str.Left(i);
	str_right = str.Right(len - i - 1);
	
	if(!(str_left == "*")){ // une etoile c'est jusquau bout
		if(is_Number(&str_left, false)) {
			low_index = _tstoi(str_left);
		}
		else {
			TRACE(traceAppMsg, 0, _T("left of box3 is not an integer:  ") + str_left + _T("/n"));
			return false;
		}
	}
	if(!(str_right == "*")) {
		if(is_Number(&str_right, false)) {
			high_index = _tstoi(str_right);
			if(high_index <= low_index) {
				TRACE(traceAppMsg, 0, str_right + _T(" has to > than ")+ str_left);
				return false;
			}
		}
		else {
			TRACE(traceAppMsg, 0, _T("right box3 is not an integer:  ") + str_right + _T("/n"));
			return false;
		}
	}

	endofcheck_range:
	
	// Check final pour path et readData
	if(mathboi.readData(path, high_index, low_index)) {
		return true;
	}
	return false;
}

bool CTp3FTSciCDlg::is_Number(CString* str,bool is_decimal){ //fonction verifiant si un string est effectivement un chiffre
	bool pt = 0;
	int len = str->GetLength();
	for(int i = 0;i < len;i++) {
		switch(str->GetAt(i)){
		case('0'): case('1'):case('2'):case('3'):case('4'):case('5'):case('6'):case('7'):case('8'):case('9'):
			break;
		case('.'):
			if(pt == 0 && is_decimal) {
				pt++;
			}
			else {
				return false;
			}
			break;
		default:
			return false;
			break;
		}
	}
	return true;
}

void CTp3FTSciCDlg::make_appear() {//fait apparaitre l'image       //Jai juste des belle chose a dire sure microsoft ...........
	if(NULL == mydisplay) {
		CString id = _T("IDD_PROPPAGE_LARGE");
		mydisplay = new fonction_display(this);
		mydisplay->Create(IDD_DISPLAYFCTS, this);
	}
	mydisplay->ShowWindow(SW_SHOW); 
}