
// Tp3_FT_SciCDlg.h : header file
//
#include "FT_Math.h"
#include <direct.h>
#include "fonction_display.h"
#include "Resource.h"

#pragma once


// CTp3FTSciCDlg dialog
class CTp3FTSciCDlg : public CDialogEx
{
// Construction
public:
	CTp3FTSciCDlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TP3_FT_SCIC_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	fonction_display* mydisplay;
	void kill_child_bn();
	afx_msg void OnbnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	CEdit box1;
	CEdit box2;
	CEdit box3;
	afx_msg void OnBnClickedApproxim();
private:
	bool checkInputs();
	bool is_Number(CString* str, bool is_decimal);
	void make_appear();
	FT_Math mathboi;
public:
//	virtual BOOL Create(LPCTSTR lpszTemplateName, CWnd* pParentWnd = NULL);
//	virtual BOOL DestroyWindow();
//	virtual BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam = NULL);
//	virtual BOOL Create(LPCTSTR lpszTemplateName, CWnd* pParentWnd = NULL);
//	virtual BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam = NULL);
//	virtual BOOL DestroyWindow();
};
