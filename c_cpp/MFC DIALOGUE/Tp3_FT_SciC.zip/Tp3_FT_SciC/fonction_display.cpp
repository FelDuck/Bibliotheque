// fonction_display.cpp : implementation file
//

#include "pch.h"
#include "Tp3_FT_SciC.h"
#include "afxdialogex.h"
#include "fonction_display.h"
#include "ftdlg.h"

//#include "Tp3_FT_SciCDlg.h"

// fonction_display dialog

IMPLEMENT_DYNAMIC(fonction_display, CDialogEx)

	
fonction_display::fonction_display(CWnd* pParent /*=nullptr*/)
	: CDialogEx(108, pParent){
	
}

fonction_display::~fonction_display()
{
}
/*
void fonction_display::setParent(CTp3FTSciCDlg* p){
	parent = p;
}
*/
void fonction_display::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(fonction_display, CDialogEx)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDD_KILLCHILD, &fonction_display::OnBnClickedQuit)
END_MESSAGE_MAP()


// fonction_display message handlers


BOOL fonction_display::OnInitDialog()
{
	

	
	

	// TODO: Add extra initialization here

	

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void fonction_display::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CDialogEx::OnPaint() for painting messages
}


void fonction_display::OnBnClickedQuit()
{
	// C'est pas la solution  que je voulais mais si je jinclut ftdlg.h dans fonction_display.h
	// sa brise l'application ???????
	void* x = (void*)GetParent();
	((CTp3FTSciCDlg*)x)->kill_child_bn();
	
	//this->DestroyWindow();
	//parnt->kill_child_bn();
}
