Document et Project realiser au complet par: Felix Theriault (sauf les fonctions de numerical recipe mais je lais ais pas fait marcher anyway)

Honnetement je suis decu, j'ai perdu tellement de temps a gosser avec l'interface que ce soit avec cette bibliotheque ci ou en esseyant d'en trouver
une qui pourrait aussi marcher pour un project de jeux video que j'aimerais me monter ... finalement j'ai decider de retourner a MFC parce que sa serait
" plus simple " bon, c'est une peu de ma faute encore j'ai pas ete chercher de l'aide quand j'en avait besoin mais sa c'est un de mes grand defaut.

That being said, Microsoft vaut au moin 3 trillions de $ : https://www.forbes.com/sites/dereksaul/2024/01/24/microsoft-becomes-second-company-ever-to-top-3-trillion-valuation-how-the-tech-titan-rode-ai-to-record-heights/?sh=7b373f4040ac
Tu te dirait qu'il serait capable de monter une documentation qui vaut de l'allure >:( serieux j'ai seulement compris ce qui se passait en lisant la section
"pour ceux venant de MFC" de la documentation de Wxwidget qui est tres bien ecrit https://wxwidgets.org/docs/book/Cross-Platform%20GUI%20Programming%20with%20wxWidgets.pdf

Sinon, la majoriter du code ce passe entre CTp3FTSciCDlg qui s'occupe de la fenetre principale et controle la fenetre secondaire (qui ma vraiment fait aimer microsoft) 
et FT_Math qui s'occuppe de la majoriter des calculs.

Le plus frustrant c'est que je sait que je peut le faire. Les maths je les connait c'est rien de dure.
mais bon je sait meme pas pourquois j'ecrit tout ca.



TLDR les commentaire sont clair et explique mieux.
Felix Theriault 30 avril 2024 23h45