#include "framework.h"
#include "fonction_display.h"
#include "num_recipe/numerical_FT.h"

struct box {
	box* next;
	box* prev;
	double box_data;
	int id;
	bool endofline;
	bool startofline;
};

#pragma once
class FT_Math{


private:
	double pas;
	box* databox;
public:
	bool readData(CString,int,int);
	void set_pas(double pas) { this->pas = pas; };
	FT_Math();
	~FT_Math();
	void draw_emptygraph(fonction_display* canvas);
	void draw_lingraph(fonction_display* canvas);
	void draw_cubgraph(fonction_display* canvas);
};


