#include "pch.h"
#include "FT_Math.h"


//fonction qui lit les donner et retourne faux si il y a un probleme sinon elle retourne vrai
bool FT_Math::readData(CString path, int high_index, int low_index) {
	FILE* fichier;
	int nData = 0;
	bool eof_reached = true;
	int int_char;
	
	CString str =_T("");
	box* boxe = (box*)malloc(sizeof(box)); //woups I guess qua l'exam jai oublier le keyword struct
										   //delete pi new veulent pas marcher free / malloc it is
	boxe->endofline = true;  boxe->startofline = false;             // true pour start false pour end of line pi elle elle va se rammaser a la fin

	if(!(_wfopen_s(&fichier, path, (_T("r+"))) == 0)) {
		AfxMessageBox(_T("File path is wrong did not open"));
		goto falseboiii;
	}
	
	
	while(fgetc(fichier)!=10){} // enleve la premiere donner
	
	//boucle qui lit char par char le dossier texte et cree des boites
	while(eof_reached) {
		int_char = fgetc(fichier);
		switch(int_char) {
		case 48: case 49 : case 50 :case 51:case 52:case 53:case 54:case 55:case 56:case 57:case 46: //0 a 9 et '.'
			str.AppendChar((char)int_char);
			break;
		case 10: {// '/n'
			box* temp = boxe;
			boxe = (box*)malloc(sizeof(box));
			boxe->next = temp;
			boxe->endofline = false; boxe->startofline = false;
			temp->box_data = _tstof((LPCTSTR)str);
			temp->id = nData;
			temp->prev = boxe;
			str = _T("");
			nData++;
			}
			
			break;
		case -1: // end of file
			eof_reached = false;
			break;
		}
	}
	_fcloseall();
	
	boxe = boxe->next; //la premiere boite a pas de donner
	box* temp = boxe->prev;
	free((void*)temp);
	boxe->startofline = true;

	if(!(low_index == 0)) { // verifie pour low index
		box* BOX = boxe;
		while(!boxe->endofline) {
			boxe = boxe->next;
		}
		while(boxe->id != low_index) {
			if(boxe->startofline) { AfxMessageBox(_T("low_index est trop haut")); goto falseboiii; } //just in case
			boxe = boxe->prev;
			box* temp = boxe->next;
			free((void*)temp);
			boxe->endofline = true;

		}
		boxe = BOX;
	}

	if(high_index == -1 || high_index > nData) { //verifie pour highindex
		high_index = nData;
	}else {
		while(boxe->id != high_index) { // detruit la chaine jusqua trouver le bon index
			if(boxe->endofline) { AfxMessageBox(_T("high index est trop bas")); goto falseboiii; } //just in case
			boxe = boxe->next;
			box* temp = boxe->prev;
			free((void*)temp);
			boxe->startofline = true;
		}
	}
	databox = boxe; //enregistrement dans les donner objet
	
	
	
	
	
	return true;

falseboiii: //goto pour deallocer la memoire
	free((void*)boxe);
	return false;

}

FT_Math::FT_Math(){
	databox = NULL;
}

//destructeur detruit la chaine si elle existe
FT_Math::~FT_Math(){
	if(!(NULL == databox)) {
		while(!databox->endofline) {
			databox = databox->next;
			box* temp = databox->prev;
			free((void*)temp);
		}
		free((void*)databox);
	}
}

//dessinne un cadre vide et les points
void FT_Math::draw_emptygraph(fonction_display* canvas){
	box* boxe = databox;
	int low, high;
	high = boxe->id;
	while(!boxe->endofline) {
		boxe = boxe->next;
	}
	low = boxe->id;

	double temp,stepped, step = 500 / (high-low);

	CClientDC toile(canvas);
	CPen blackpen,bluepen;
	bluepen.CreatePen(BS_SOLID, 2, RGB(0, 0, 255));
	blackpen.CreatePen(BS_SOLID, 3, RGB(0, 0, 0));
	toile.SelectObject(&blackpen);
	toile.MoveTo(10, 0);
	toile.LineTo(10,370);
	toile.LineTo(510, 370);
	
	toile.SelectObject(&bluepen);
	stepped = step;

	while(!boxe->startofline) {
		temp = 370 - boxe->box_data;
		toile.MoveTo((int)step, (int)temp);
		toile.Ellipse((int)stepped - 2, (int)temp - 2, (int)stepped + 2, (int)temp + 2);
		stepped += step;
		boxe = boxe->prev;
	}
	temp = 510 - boxe->box_data;
	toile.MoveTo((int)step, (int)temp);
	toile.Ellipse((int)stepped - 2, (int)temp - 2, (int)stepped + 2, (int)temp + 2);
}

void FT_Math::draw_lingraph(fonction_display* canvas) { // une fonction qui marche
	box* boxe = databox;
	int low, high;
	high = boxe->id;
	
	while(!boxe->endofline) { //rewind la chaine de box
		boxe = boxe->next;
	}
	low = boxe->id;

	double temp, stepped, step = 500 / (high - low);

	CClientDC toile(canvas);
	CPen redpen;
	redpen.CreatePen(BS_SOLID, 0, RGB(255, 0, 0));
	
	toile.SelectObject(&redpen);
	stepped = step;
	temp = 370 - boxe->box_data;
	toile.MoveTo((int)step, (int)temp);
	//dessinne chaqu'un des points avec une methode pareille a plus haut sauf que c<unne une ligne rouge
	while(!boxe->startofline) { 
		temp = 370 - boxe->box_data;
		toile.LineTo((int)stepped, (int)temp);
		stepped += step;
		boxe = boxe->prev;
	}
	temp = 370 - boxe->box_data;
	toile.LineTo((int)stepped, (int)temp);
}

void FT_Math::draw_cubgraph(fonction_display* canvas) { //fonction qui devrait faire apparaitre la fonction spline si il y avait pas 11 linker error
	box* boxe = databox;
	int low, high;
	high = boxe->id;
	float* x, *y, *y2,*yfin;
	yfin = new float;
	x = new float[high];
	y = new float[high];
	y2 = new float[high];
	float yp = (float)2 * pow(10, 30);
	double past = pas, temp, temp2, pixel_s, pixel;

	for(int i = 0; i < high; i++) { // set les donner
		x[i] = (float)past;
		y[i] = 0;
		y2[i] = 0;
	}
	
	
	
	//rammasse les donner des boites
	while(!boxe->endofline) { 
		y[boxe->id] = boxe->box_data;
		boxe = boxe->next;

	}
	low = boxe->id;
	y[boxe->id] = boxe->box_data;
	spline(x, y, high, 0, yp, y2);


	pixel = (x[high])/500; //je voulait faire apparaitre la fonction pour chaque pixels

	CClientDC toile(canvas);
	CPen greenpen;
	greenpen.CreatePen(BS_SOLID, 0, RGB(0, 255, 0));

	toile.SelectObject(&greenpen);
	pixel_s = pixel;
	
	for(int i; i < 500; i++) {
		splint(x, y, y2, high, pixel_s, yfin);
		temp = 370 - *yfin;
		toile.LineTo((int)pixel + 10, (int)temp);
		pixel_s += pixel;
	}
	delete yfin;
	delete[] x;
	delete[] y;
	delete[] y2;
}