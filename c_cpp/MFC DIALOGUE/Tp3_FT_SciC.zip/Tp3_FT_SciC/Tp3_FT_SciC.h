
// Tp3_FT_SciC.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols
#include "ftdlg.h"

// CTp3FTSciCApp:
// See Tp3_FT_SciC.cpp for the implementation of this class
//

class CTp3FTSciCApp : public CWinApp
{
public:
	CTp3FTSciCApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CTp3FTSciCApp theApp;
