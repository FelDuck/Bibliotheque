#pragma once
#include "afxdialogex.h"
#include "Resource.h"


// fonction_display dialog

class fonction_display : public CDialogEx
{
	DECLARE_DYNAMIC(fonction_display)

public:
	fonction_display(CWnd* pParent = nullptr);   // standard constructor
	virtual ~fonction_display();
	//CTp3FTSciCDlg* parent;
	//void setParent(CTp3FTSciCDlg* p);
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PROPPAGE_LARGE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnBnClickedQuit();
	
};
