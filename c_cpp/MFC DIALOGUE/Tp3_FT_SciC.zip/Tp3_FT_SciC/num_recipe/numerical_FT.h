/*
Je voulais vraiment vraiment implementer mes propres version de ces methodes mais comme il est rendu 22h22 le 30 avril j'ai comme pas le choix
*/

extern void splint(float* xa, float* ya, float* y2a,int n,float x, float* y);
extern void spline(float* x, float* y,int n,float yp1,float ypn,float* y2);